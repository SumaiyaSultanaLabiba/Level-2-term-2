/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 69.6, "KoPercent": 30.4};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.696, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.36, 500, 1500, "Notices"], "isController": false}, {"data": [0.12, 500, 1500, "Courses"], "isController": false}, {"data": [1.0, 500, 1500, "Login"], "isController": false}, {"data": [1.0, 500, 1500, "Home"], "isController": false}, {"data": [1.0, 500, 1500, "Download"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 250, 76, 30.4, 132.49199999999996, 4, 420, 77.0, 310.70000000000005, 348.45, 411.9200000000001, 2.533826584908529, 157.536213924644, 0.878426208635281], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Notices", 50, 32, 64.0, 263.1399999999999, 124, 420, 265.0, 382.3, 411.59999999999997, 420.0, 0.508931752252023, 3.7364735482721767, 0.17643630082955875], "isController": false}, {"data": ["Courses", 50, 44, 88.0, 260.62, 184, 395, 252.0, 319.9, 326.79999999999995, 395.0, 0.5097619411734721, 22.106443868838255, 0.17672411046541267], "isController": false}, {"data": ["Login", 50, 0, 0.0, 18.399999999999995, 4, 47, 16.5, 34.9, 35.89999999999999, 47.0, 0.5111481409542113, 0.7712147243889224, 0.17620634155941076], "isController": false}, {"data": ["Home", 50, 0, 0.0, 54.22000000000001, 17, 120, 53.5, 84.5, 101.69999999999997, 120.0, 0.5096008805903216, 1.211297405621917, 0.17318467426311712], "isController": false}, {"data": ["Download", 50, 0, 0.0, 66.08, 17, 168, 59.5, 120.69999999999999, 150.4499999999999, 168.0, 0.5107513151846366, 130.89149646943153, 0.1815561315695388], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 308 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 261 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 329 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 288 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 302 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 406 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 420 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 370 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 289 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 283 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 376 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 214 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 307 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 293 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 3.9473684210526314, 1.2], "isController": false}, {"data": ["The operation lasted too long: It took 312 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 416 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 318 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 246 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 317 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 395 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 349 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 227 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 241 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 244 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 270 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 295 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 324 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 311 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 266 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 237 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 260 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 243 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 362 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 383 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 264 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 358 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 239 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 286 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 217 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 233 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 320 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 254 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 408 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 249 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 216 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 248 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 219 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 252 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 367 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 297 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 223 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 325 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 203 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 229 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 281 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 348 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 271 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 242 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 306 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 2.6315789473684212, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 287 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 1.3157894736842106, 0.4], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 250, 76, "The operation lasted too long: It took 293 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, "The operation lasted too long: It took 319 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 312 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 227 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 241 milliseconds, but should not have lasted longer than 200 milliseconds.", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Notices", 50, 32, "The operation lasted too long: It took 308 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 362 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 288 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 383 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 264 milliseconds, but should not have lasted longer than 200 milliseconds.", 1], "isController": false}, {"data": ["Courses", 50, 44, "The operation lasted too long: It took 293 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 312 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 254 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 216 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 252 milliseconds, but should not have lasted longer than 200 milliseconds.", 2], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
