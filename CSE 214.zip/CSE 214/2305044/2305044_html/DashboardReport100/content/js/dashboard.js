/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 67.2, "KoPercent": 32.8};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.672, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.28, 500, 1500, "Notices"], "isController": false}, {"data": [0.12, 500, 1500, "Courses"], "isController": false}, {"data": [1.0, 500, 1500, "Login"], "isController": false}, {"data": [1.0, 500, 1500, "Home"], "isController": false}, {"data": [0.96, 500, 1500, "Download"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 500, 164, 32.8, 136.90599999999986, 3, 488, 84.5, 301.90000000000003, 358.79999999999995, 415.0, 5.01665529558133, 311.9017246633824, 1.7391724901673555], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Notices", 100, 72, 72.0, 267.5, 123, 437, 259.0, 396.8, 411.9, 436.93999999999994, 1.0081559818935184, 7.401676437378391, 0.3495072007541007], "isController": false}, {"data": ["Courses", 100, 88, 88.0, 260.56, 173, 488, 256.5, 328.9, 375.9, 487.4099999999997, 1.0087254753618804, 43.74460174257326, 0.34970463257174556], "isController": false}, {"data": ["Login", 100, 0, 0.0, 20.110000000000003, 3, 71, 16.0, 39.900000000000006, 50.94999999999999, 70.92999999999996, 1.0104480326576804, 1.5245529398985511, 0.3483282768829699], "isController": false}, {"data": ["Home", 100, 0, 0.0, 63.43000000000001, 11, 155, 55.5, 121.60000000000002, 134.95, 154.8499999999999, 1.0091733860794623, 2.3987578337084097, 0.3429612679254423], "isController": false}, {"data": ["Download", 100, 4, 4.0, 72.92999999999999, 17, 246, 55.0, 153.60000000000002, 177.79999999999995, 245.92999999999995, 1.0095707305253807, 258.72517560220894, 0.3588708456164439], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 410 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 204 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 308 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 261 milliseconds, but should not have lasted longer than 200 milliseconds.", 4, 2.4390243902439024, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 288 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 380 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 256 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 268 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 301 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 283 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 355 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 214 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 397 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 437 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 278 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 251 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 246 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 395 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 231 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 273 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 392 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 276 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 363 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 224 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 298 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 295 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 202 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 221 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 311 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 350 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 266 milliseconds, but should not have lasted longer than 200 milliseconds.", 4, 2.4390243902439024, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 353 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 243 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 222 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 403 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 239 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 253 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 218 milliseconds, but should not have lasted longer than 200 milliseconds.", 4, 2.4390243902439024, 0.8], "isController": false}, {"data": ["The operation lasted too long: It took 232 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 238 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 286 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 259 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 212 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 290 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 429 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 233 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 402 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 336 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 280 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 228 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 249 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 374 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 291 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 219 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 252 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 412 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 223 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 297 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 262 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 203 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 281 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 271 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 282 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 386 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 431 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 267 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 329 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 257 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 240 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 302 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 354 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 391 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 289 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 235 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 376 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 272 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 225 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 344 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 299 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 359 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 349 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 227 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 488 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 414 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 279 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 292 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 260 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 327 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 347 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 211 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 372 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 351 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 331 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 217 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 352 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 201 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 341 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 255 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 206 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 328 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 415 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 265 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 387 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 348 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 274 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}, {"data": ["The operation lasted too long: It took 226 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 245 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, 1.829268292682927, 0.6], "isController": false}, {"data": ["The operation lasted too long: It took 284 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, 1.2195121951219512, 0.4], "isController": false}, {"data": ["The operation lasted too long: It took 303 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, 0.6097560975609756, 0.2], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 500, 164, "The operation lasted too long: It took 261 milliseconds, but should not have lasted longer than 200 milliseconds.", 4, "The operation lasted too long: It took 266 milliseconds, but should not have lasted longer than 200 milliseconds.", 4, "The operation lasted too long: It took 218 milliseconds, but should not have lasted longer than 200 milliseconds.", 4, "The operation lasted too long: It took 288 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, "The operation lasted too long: It took 221 milliseconds, but should not have lasted longer than 200 milliseconds.", 3], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Notices", 100, 72, "The operation lasted too long: It took 261 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 380 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 289 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 397 milliseconds, but should not have lasted longer than 200 milliseconds.", 2, "The operation lasted too long: It took 347 milliseconds, but should not have lasted longer than 200 milliseconds.", 2], "isController": false}, {"data": ["Courses", 100, 88, "The operation lasted too long: It took 267 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, "The operation lasted too long: It took 266 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, "The operation lasted too long: It took 255 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, "The operation lasted too long: It took 206 milliseconds, but should not have lasted longer than 200 milliseconds.", 3, "The operation lasted too long: It took 261 milliseconds, but should not have lasted longer than 200 milliseconds.", 2], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Download", 100, 4, "The operation lasted too long: It took 212 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 211 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 239 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "The operation lasted too long: It took 246 milliseconds, but should not have lasted longer than 200 milliseconds.", 1, "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
